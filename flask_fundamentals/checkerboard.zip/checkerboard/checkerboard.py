from flask import Flask, render_template
app = Flask(__name__)


@app.route('/')
def checker():
    return render_template("checkerboard.html")


@app.route('/<num>')
def square(num):
    num = int(num)
    return render_template("checkerboard.html", blocknum=num)


if __name__ == "__main__":
    app.run(debug=True)
